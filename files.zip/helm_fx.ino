/*
  helm_fx.ino – Effekt-Controller für den Spartan-Helm
  ----------------------------------------------------
  Board:    Arduino Nano (ATmega328P, Original oder Klon mit CH340)
  Library:  FastLED  (Arduino IDE → Bibliotheksverwalter → "FastLED")

  Der Nano hängt per USB am Raspberry Pi 5 (Strom + Daten) und steuert:
    D6  → 4× WS2812B am Visier            (über 330 Ω)
    D5  → WS2812B-Streifen am Rücken      (über 330 Ω)
    D9  → Lüfter über Logic-Level-MOSFET  (PWM 31 kHz, kein Pfeifen)
    D3  → Nebler 1 (MOSFET oder Optokoppler)
    D4  → Nebler 2
    D2  ← Taster gegen GND (manueller Nebelstoß, z. B. im Handschuh)

  Serielles Protokoll (115200 Baud, eine Zeile pro Befehl):
    PING                     -> PONG
    V <MODUS> [R G B]        Visier   MODUS: OFF SOLID PULSE RAINBOW CHASE ALERT FIRE SCAN
    B <MODUS> [R G B]        Rücken   (gleiche Modi)
    BRI <V|B> <0-255>        Helligkeit je Gruppe
    FAN <0-100>              Lüfter in Prozent
    FOG <0|1|2> <ms>         Nebel: 1 = links, 2 = rechts, 0 = beide
    STOP                     Rücken-LEDs + Nebel aus (Lüfter laufen weiter!)
  Antworten:  OK | PONG | ERR <grund>
  Meldungen:  READY (nach Start) | EVT BTN | EVT LINKLOST

  Sicherheit (gilt auch, wenn der Pi abstürzt):
    • Nebel max. FOG_MAX_MS am Stück, danach Pflichtpause
    • Kein Lebenszeichen vom Pi → Nebel aus, Lüfter mind. FAN_DEFAULT
    • LED-Strom wird auf LED_MAX_MA begrenzt
*/
#include <FastLED.h>

// ------------------------------ Pins ------------------------------
#define PIN_VISOR   6
#define PIN_BACK    5
const uint8_t PIN_FAN     = 9;
const uint8_t PIN_FOG1    = 3;
const uint8_t PIN_FOG2    = 4;
const uint8_t PIN_FOG_BTN = 2;

#define NUM_VISOR   4
#define NUM_BACK    60        // an deinen Streifen anpassen

// ---------------------- Sicherheit / Grenzwerte ----------------------
const uint32_t FOG_MAX_MS      = 5000;   // längster Nebelstoß am Stück
const uint32_t FOG_COOLDOWN_MS = 3000;   // Pause danach (Heizdraht / Pumpe schonen)
const uint32_t FOG_BTN_MS      = 2000;   // Dauer beim Tasterdruck
const uint8_t  FAN_DEFAULT     = 60;     // %  – Startwert, auch ohne Pi
const uint8_t  FAN_MIN         = 25;     // %  – darunter laufen viele Lüfter nicht an
const uint32_t LINK_TIMEOUT_MS = 15000;  // kein Befehl/PING vom Pi → sicherer Zustand
const uint16_t LED_MAX_MA      = 1500;   // Strombudget aller LEDs an Powerbank B

// ------------------------------ Zustand ------------------------------
enum Mode : uint8_t { M_OFF, M_SOLID, M_PULSE, M_RAINBOW, M_CHASE, M_ALERT, M_FIRE, M_SCAN };
const char* const MODE_NAMES[] = { "OFF", "SOLID", "PULSE", "RAINBOW", "CHASE", "ALERT", "FIRE", "SCAN" };
const uint8_t MODE_COUNT = sizeof(MODE_NAMES) / sizeof(MODE_NAMES[0]);

struct Group {
  CRGB*   leds;
  uint8_t n;
  Mode    mode;
  CRGB    color;
  uint8_t bri;
};

CRGB visorLeds[NUM_VISOR];
CRGB backLeds[NUM_BACK];
Group visorGrp = { visorLeds, NUM_VISOR, M_PULSE, CRGB(255, 140, 0), 160 };  // Gold beim Start
Group backGrp  = { backLeds,  NUM_BACK,  M_OFF,   CRGB(0, 90, 255),  200 };

struct Fogger {
  uint8_t  pin;
  bool     on;
  uint32_t startedAt;
  uint32_t offAt;
  uint32_t readyAt;
};
Fogger fog[2] = { { PIN_FOG1, false, 0, 0, 0 }, { PIN_FOG2, false, 0, 0, 0 } };

uint8_t  fanPct     = 0;
bool     linkOk     = false;
uint32_t lastRx     = 0;
uint32_t quietUntil = 0;    // LED-Ausgabe pausiert, solange Daten ankommen
char     line[48];
uint8_t  lineLen    = 0;

// ------------------------------ Lüfter ------------------------------
void setFan(int pct) {
  pct = constrain(pct, 0, 100);
  if (pct > 0 && pct < FAN_MIN) pct = FAN_MIN;
  if (fanPct == 0 && pct > 0) {         // Anlaufhilfe: kurz volle Spannung
    analogWrite(PIN_FAN, 255);
    delay(300);
  }
  fanPct = pct;
  analogWrite(PIN_FAN, map(pct, 0, 100, 0, 255));
}

// ------------------------------ Nebel ------------------------------
inline bool reached(uint32_t t) { return (int32_t)(millis() - t) >= 0; }   // überlauf-sicher

bool fogStart(uint8_t i, uint32_t ms) {
  Fogger& f = fog[i];
  uint32_t now = millis();
  if (!f.on) {
    if (!reached(f.readyAt)) return false;            // noch in der Pflichtpause
    f.on = true;
    f.startedAt = now;
    digitalWrite(f.pin, HIGH);
  }
  uint32_t used = now - f.startedAt;
  uint32_t left = (used < FOG_MAX_MS) ? FOG_MAX_MS - used : 0;
  f.offAt = now + min(ms, left);
  return true;
}

void fogStop(uint8_t i) {
  Fogger& f = fog[i];
  digitalWrite(f.pin, LOW);
  if (f.on) f.readyAt = millis() + FOG_COOLDOWN_MS;
  f.on = false;
}

void fogUpdate() {
  for (uint8_t i = 0; i < 2; i++)
    if (fog[i].on && reached(fog[i].offAt)) fogStop(i);
}

// ------------------------------ LED-Effekte ------------------------------
void render(Group& g, uint32_t t) {
  CRGB* L = g.leds;
  uint8_t n = g.n;
  switch (g.mode) {
    case M_OFF:
      fill_solid(L, n, CRGB::Black);
      break;
    case M_SOLID:
      fill_solid(L, n, g.color);
      break;
    case M_PULSE: {
      CRGB c = g.color;
      c.nscale8_video(beatsin8(18, 40, 255));
      fill_solid(L, n, c);
    } break;
    case M_RAINBOW:
      fill_rainbow(L, n, (uint8_t)(t / 12), max(1, 255 / n));
      break;
    case M_CHASE:
      fadeToBlackBy(L, n, 40);
      L[(t / 30) % n] = g.color;
      break;
    case M_ALERT:
      fill_solid(L, n, ((t / 150) % 2) ? g.color : CRGB::Black);
      break;
    case M_FIRE:
      for (uint8_t i = 0; i < n; i++)
        L[i] = ColorFromPalette(HeatColors_p, qsub8(inoise8(i * 60, (uint16_t)(t / 2)), 30));
      break;
    case M_SCAN: {                       // Lauflicht hin und her
      fadeToBlackBy(L, n, 60);
      uint8_t p = (n > 1) ? beatsin8(25, 0, n - 1) : 0;
      L[p] = g.color;
    } break;
  }
  if (g.bri < 255)
    for (uint8_t i = 0; i < n; i++) L[i].nscale8_video(g.bri);
}

// ------------------------------ Befehle ------------------------------
bool parseMode(const char* s, Mode& out) {
  if (!s) return false;
  for (uint8_t i = 0; i < MODE_COUNT; i++)
    if (!strcmp(s, MODE_NAMES[i])) { out = (Mode)i; return true; }
  return false;
}

void handle(char* cmd) {
  linkOk = true;
  char* tok = strtok(cmd, " ");
  if (!tok) return;

  if (!strcmp(tok, "PING")) { Serial.println(F("PONG")); return; }

  if (!strcmp(tok, "V") || !strcmp(tok, "B")) {
    Group& g = (tok[0] == 'V') ? visorGrp : backGrp;
    Mode m;
    if (!parseMode(strtok(NULL, " "), m)) { Serial.println(F("ERR MODE")); return; }
    char* r = strtok(NULL, " ");
    char* gr = strtok(NULL, " ");
    char* b = strtok(NULL, " ");
    if (r && gr && b) g.color = CRGB(constrain(atoi(r), 0, 255), constrain(atoi(gr), 0, 255), constrain(atoi(b), 0, 255));
    g.mode = m;
    Serial.println(F("OK"));
    return;
  }

  if (!strcmp(tok, "BRI")) {
    char* which = strtok(NULL, " ");
    char* val = strtok(NULL, " ");
    if (!which || !val) { Serial.println(F("ERR ARGS")); return; }
    Group& g = (which[0] == 'V') ? visorGrp : backGrp;
    g.bri = constrain(atoi(val), 0, 255);
    Serial.println(F("OK"));
    return;
  }

  if (!strcmp(tok, "FAN")) {
    char* val = strtok(NULL, " ");
    if (!val) { Serial.println(F("ERR ARGS")); return; }
    setFan(atoi(val));
    Serial.println(F("OK"));
    return;
  }

  if (!strcmp(tok, "FOG")) {
    char* which = strtok(NULL, " ");
    char* dur = strtok(NULL, " ");
    if (!which || !dur) { Serial.println(F("ERR ARGS")); return; }
    int w = atoi(which);
    uint32_t ms = (uint32_t)atol(dur);
    bool started = false;
    if (w == 0 || w == 1) started |= fogStart(0, ms);
    if (w == 0 || w == 2) started |= fogStart(1, ms);
    Serial.println(started ? F("OK") : F("ERR COOLDOWN"));
    return;
  }

  if (!strcmp(tok, "STOP")) {
    backGrp.mode = M_OFF;
    fogStop(0);
    fogStop(1);
    Serial.println(F("OK"));
    return;
  }

  Serial.println(F("ERR CMD"));
}

void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    lastRx = millis();
    quietUntil = lastRx + 25;   // FastLED sperrt beim Senden die Interrupts → sonst gehen Bytes verloren
    if (c == '\r') continue;
    if (c == '\n') {
      line[lineLen] = 0;
      if (lineLen) handle(line);
      lineLen = 0;
    } else if (lineLen < sizeof(line) - 1) {
      line[lineLen++] = toupper(c);
    }
  }
}

// ------------------------------ Taster & Watchdog ------------------------------
void checkButton() {
  static bool last = HIGH;
  static uint32_t changedAt = 0;
  bool s = digitalRead(PIN_FOG_BTN);
  if (s != last && millis() - changedAt > 40) {
    changedAt = millis();
    last = s;
    if (s == LOW) {
      fogStart(0, FOG_BTN_MS);
      fogStart(1, FOG_BTN_MS);
      Serial.println(F("EVT BTN"));
    }
  }
}

void checkLink() {
  if (linkOk && millis() - lastRx > LINK_TIMEOUT_MS) {
    linkOk = false;
    fogStop(0);
    fogStop(1);
    if (fanPct < FAN_DEFAULT) setFan(FAN_DEFAULT);
    visorGrp.mode = M_PULSE;            // langsames Orange = "Pi offline"
    visorGrp.color = CRGB(255, 60, 0);
    backGrp.mode = M_OFF;
    Serial.println(F("EVT LINKLOST"));
  }
}

// ------------------------------ Setup / Loop ------------------------------
void setup() {
  digitalWrite(PIN_FOG1, LOW);
  digitalWrite(PIN_FOG2, LOW);
  pinMode(PIN_FOG1, OUTPUT);
  pinMode(PIN_FOG2, OUTPUT);
  pinMode(PIN_FOG_BTN, INPUT_PULLUP);
  pinMode(PIN_FAN, OUTPUT);

  // Timer1 ohne Vorteiler → PWM an D9/D10 mit ~31 kHz (unhörbar statt 490-Hz-Pfeifen)
  TCCR1B = (TCCR1B & 0b11111000) | 0x01;

  Serial.begin(115200);
  setFan(FAN_DEFAULT);

  // Hinweis: Manche 5-mm/8-mm-WS2812-LEDs sind RGB statt GRB → Farbreihenfolge hier tauschen
  FastLED.addLeds<WS2812B, PIN_VISOR, GRB>(visorLeds, NUM_VISOR);
  FastLED.addLeds<WS2812B, PIN_BACK, GRB>(backLeds, NUM_BACK);
  FastLED.setMaxPowerInVoltsAndMilliamps(5, LED_MAX_MA);
  FastLED.clear(true);

  lastRx = millis();
  Serial.println(F("READY"));
}

void loop() {
  readSerial();
  checkButton();
  fogUpdate();
  checkLink();

  EVERY_N_MILLISECONDS(20) {            // ~50 Bilder/s
    if (reached(quietUntil)) {
      uint32_t t = millis();
      render(visorGrp, t);
      render(backGrp, t);
      FastLED.show();
    }
  }
}
