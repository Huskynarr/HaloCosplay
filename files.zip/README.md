# Spartan-Helm – Verdrahtung & Inbetriebnahme

Raspberry Pi 5 als Gehirn (Audio, Sprachbefehle, HUD, Kamera-KI), Arduino Nano als Effekt-Controller (LEDs, Lüfter, Nebler). Beide sind per USB verbunden.

```
spartan-helm/
├── arduino/helm_fx/helm_fx.ino   → auf den Nano flashen (Library: FastLED)
└── pi/
    ├── helm.py                   → Hauptprogramm
    ├── setup.sh                  → Installation + Autostart
    └── helm.service              → systemd-Vorlage (setup.sh trägt Pfade ein)
```

## Stückliste

| Teil | Empfehlung | Zweck |
|---|---|---|
| Rechner | Raspberry Pi 5 (4 GB reicht) + Active Cooler | Hauptsteuerung |
| Kamera 1 | Raspberry Pi AI Camera (IMX500) | Objekterkennung direkt auf dem Kamerachip |
| Kamera 2 | Camera Module 3 Wide (optional) | Aufnahme / zweite Sicht, Port CAM1 |
| Display | 1,51″ Transparent OLED 128×64, SSD1309, SPI (z. B. Waveshare) | HUD im Visier |
| Audio-Interface | USB-Soundkarte mit Mic-In und Kopfhörer-Out | Mikrofon rein, Ton innen raus |
| Mikrofon | Lavalier-Mikro (3,5 mm, Plug-in-Power) nah am Mund | Befehle + Stimme |
| Verstärker außen | MAX98357A (I2S, 3 W) | Außenlautsprecher |
| Lautsprecher außen | 4 Ω, 3 W, 40–50 mm | Stimme nach außen |
| Verstärker innen | PAM8403 (Stereo, gern mit Poti) | 2 innere Lautsprecher |
| Lautsprecher innen | 2× 8 Ω, 0,5–1 W, ca. 28 mm | Rückmeldungen am Ohr |
| Effekt-Controller | Arduino Nano | LEDs, Lüfter, Nebler |
| Visier-LEDs | 4× WS2812B (einzeln oder Streifenstück) | RGB am Visier |
| Rücken-LEDs | WS2812B-Streifen, 5 V, z. B. 60 LEDs | Show-Effekte |
| Lüfter | 2× 5-V-Lüfter 30/40 mm oder Radial-Gebläse | Belüftung |
| Schalttransistoren | 3× IRLZ44N (oder fertiges Dual-MOSFET-Modul D4184) | Lüfter + Nebler |
| Optokoppler | 2× PC817 (nur falls Nebler eigenen Auslöse-Taster hat) | potentialfreies Auslösen |
| Kleinteile | 2× 330 Ω, 3× 220 Ω, 3× 10 kΩ, 3× 1N5819, 1000 µF/10 V, Taster, Sicherungen | |
| Stecker | GX16-8 (Helm ↔ Rücken) | Helm abnehmbar |
| Strom | Powerbank A ≥ 20.000 mAh USB-C PD (5 V/3 A), Powerbank B 5 V/3 A, Akku für Nebler | |

## Raspberry Pi 5 – Pinbelegung

| Pi-Pin | GPIO | Verbunden mit |
|---|---|---|
| 1 | 3,3 V | OLED VCC |
| 4 | 5 V | PAM8403 +5V |
| 6 / 9 / 39 | GND | OLED GND, Taster, PAM8403 GND, MAX98357A GND |
| 11 | GPIO17 | PTT-Taster (andere Seite an GND, Pin 9) |
| 12 | GPIO18 | MAX98357A BCLK |
| 35 | GPIO19 | MAX98357A LRC |
| 40 | GPIO21 | MAX98357A DIN |
| 19 | GPIO10 (MOSI) | OLED DIN |
| 23 | GPIO11 (SCLK) | OLED CLK |
| 24 | GPIO8 (CE0) | OLED CS |
| 22 | GPIO25 | OLED DC |
| 18 | GPIO24 | OLED RST |
| CAM/DISP 0 | – | AI Camera (22-auf-15-Pin-Flachbandkabel für den Pi 5) |
| CAM/DISP 1 | – | Kamera 2 (optional) |
| USB | – | USB-Soundkarte, Arduino Nano |

MAX98357A: VIN an den 5-V-FX-Bus (Powerbank B), GND gemeinsam, SD und GAIN offen lassen (an, 9 dB). Lautsprecher an die Klemmen + / −.
PAM8403: Eingang L/R/GND vom Kopfhörer-Ausgang der USB-Soundkarte. **Lautsprecher-Minus nie mit GND verbinden** (Brückenendstufe).
OLED: Viele Module haben Lötbrücken für SPI/I2C – auf 4-Draht-SPI stellen.

## Arduino Nano – Pinbelegung

| Nano-Pin | Verbunden mit |
|---|---|
| D6 | 330 Ω → DIN der 4 Visier-LEDs |
| D5 | 330 Ω → DIN Rücken-Streifen (über Nabelschnur) |
| D9 | 220 Ω → Gate MOSFET Lüfter |
| D3 | 220 Ω → Gate MOSFET Nebler 1 (oder 330 Ω → PC817) |
| D4 | 220 Ω → Gate MOSFET Nebler 2 (oder 330 Ω → PC817) |
| D2 | Nebel-Taster, andere Seite an GND |
| GND | gemeinsame Masse mit FX-Bus und Nebler-Kreis |
| USB | Raspberry Pi (Strom + Daten) |

WS2812B: 5 V und GND direkt vom FX-Bus, 1000 µF direkt an den Anfang jedes Streifens.

## MOSFET-Stufe (Lüfter und Nebler, je eine)

```
  +5 V (FX-Bus bzw. Nebler-Akku) ────────┬──────────── Last  +
                                         │
                                   1N5819 (Kathode an +)      ← nur bei Motor/Pumpe/Lüfter
                                         │
                                         └──────────── Last  −  ── Drain  (IRLZ44N)
  Arduino Dx ──[220 Ω]──┬────────────────────────────────────────── Gate
                        │
                     [10 kΩ]   (hält das Gate beim Booten sicher auf LOW)
                        │
  GND ──────────────────┴────────────────────────────────────────── Source
```

Variante für fertige Nebler mit eigenem Akku und Auslöse-Taster: PC817 parallel zum Taster.
Anode (Pin 1) über 330 Ω an D3/D4, Kathode (Pin 2) an GND, Kollektor (Pin 4) an die Plus-Seite des Tasters, Emitter (Pin 3) an die Minus-Seite (Polarität am Taster vorher messen).

## Stromversorgung

| Quelle | Versorgt | Absicherung |
|---|---|---|
| Powerbank A (USB-C PD, 5 V/3 A) | Pi 5 → Kameras, OLED, USB-Soundkarte, Nano, PAM8403 | – |
| Powerbank B (5 V/3 A) | FX-Bus: WS2812B, Lüfter, MAX98357A | 3-A-Sicherung + Schalter |
| Nebler-Akku | Nebler | Sicherung passend zum Nebler + Not-Aus-Schalter |

Alle GND-Leitungen verbinden (sonst funktionieren LED-Daten und MOSFETs nicht).
Der Pi 5 meldet an einer normalen Powerbank „kein 5-A-Netzteil“ und begrenzt USB auf 600 mA – das reicht hier, weil Soundkarte + Nano nur ca. 150 mA ziehen. Die LEDs hängen bewusst nicht am Pi.
Laufzeit grob: Pi mit 20.000 mAh ca. 5–7 h, FX-Bus mit 10.000 mAh je nach LED-Effekt 4–8 h.

## Nabelschnur Helm ↔ Rücken (GX16-8)

| Pin | Signal |
|---|---|
| 1, 3 | +5 V FX-Bus (zum Helm: Lüfter, Visier-LEDs, MAX98357A) |
| 2, 4 | GND |
| 5 | LED-Daten Rücken (D5) |
| 6 | Nebler 1 (D3) |
| 7 | Nebler 2 (D4) |
| 8 | Nebel-Taster (D2) |

Dazu ein separates USB-C-Kabel von Powerbank A zum Pi. MOSFETs sitzen am Rücken direkt bei den Neblern.

## Inbetriebnahme

1. Raspberry Pi OS Lite (64-bit) installieren, Ordner `pi` nach `~/helm` kopieren, `./setup.sh` ausführen, neu starten.
2. `~/helm/venv/bin/python -m sounddevice` und `aplay -L` ausführen und bei Bedarf `MIC_DEVICE`, `OUTER_DEVICE`, `INNER_ALSA` oben in `helm.py` anpassen.
3. Nano mit der Arduino IDE flashen (Board „Arduino Nano“, bei Klonen ggf. Prozessor „ATmega328P (Old Bootloader)“). Im seriellen Monitor (115200, Zeilenende „Neue Zeile“) testen: `V RAINBOW`, `FAN 100`, `FOG 1 500`.
4. Test ohne Autostart: `sudo systemctl stop helm`, dann `~/helm/venv/bin/python ~/helm/helm.py` – Befehle lassen sich direkt eintippen.
5. Läuft alles: `sudo systemctl start helm`, Log mit `journalctl -u helm -f`.

## Sprachbefehle (PTT-Taster halten, sprechen, loslassen)

| Gesagt | Wirkung |
|---|---|
| „visier rot“ / „visier gold“ / „visier aus“ | Visierfarbe |
| „visier puls“ / „regenbogen“ / „lauflicht“ / „blinken“ | Visier-Effekt |
| „rücken blau“ / „rücken feuer“ / „licht regenbogen“ / „rücken aus“ | Rücken-LEDs |
| „visier heller“ / „rücken dunkler“ | Helligkeit |
| „nebel“ / „nebel links kurz“ / „nebel rechts lang“ | Nebelstoß (max. 5 s, danach 3 s Pause) |
| „show“ | Show-Sequenz: Lauflicht → Feuer + Nebel → Regenbogen |
| „alarm“ | alles rot blinkend |
| „scanner an“ / „scanner aus“ | Visier-Scan + Ansagen „Person links/voraus/rechts“ |
| „lüfter voll“ / „leise“ / „stärker“ / „schwächer“ / „aus“ | Lüfter |
| „stimme aus“ / „stimme an“ | Außenlautsprecher stumm/aktiv |
| „status“ | Temperatur, Verbindung, Kamera ansagen |
| „stopp“ / „ruhe“ | Rücken-LEDs und Nebel aus |

Farben: rot, grün, blau, gelb, orange, gold, weiß, lila, türkis, pink.
Neue Wörter in `KEYWORDS` bzw. `COLORS` eintragen und in `on_command_text` auswerten.

## Hinweise

- **Rückkopplung:** Mikro möglichst nah am Mund, Außenlautsprecher nach außen gerichtet. Pfeift es, `VOICE_GATE` erhöhen oder `VOICE_VOLUME` senken.
- **HUD-Schärfe:** Ein Display wenige Zentimeter vor dem Auge kann das Auge nicht scharfstellen. Abhilfe: kleine Lupenlinse (+8 bis +10 dpt) davor, oder das OLED unten/oben einbauen und über eine schräge Plexiglasscheibe spiegeln (`HUD_MIRROR = True`).
- **Nebler:** Heizdraht-Nebler werden heiß und dürfen nicht trocken laufen – die Zeitbegrenzung im Arduino-Code nicht entfernen. Nebler so montieren, dass der Nebel nicht in die Ansaugöffnung der Helmlüfter gezogen wird.
- **Lüfter:** Ansaugen am Kinn, ausblasen oben/hinten. Sie starten mit 60 % schon ohne Pi; der Pi erhöht automatisch, wenn er warm wird.
- **Pi im Helm:** Active Cooler verwenden und die warme Abluft nach außen führen, nicht Richtung Kopf.
- **Akkus:** Powerbanks nicht vollständig in Schaumstoff einpacken, und Kabel an Bewegungsstellen (Hals) mit Zugentlastung sichern.
