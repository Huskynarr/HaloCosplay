#!/usr/bin/env bash
# setup.sh – Einrichtung auf dem Raspberry Pi 5
# Empfohlen: Raspberry Pi OS Lite (64-bit). Ordner "pi" z. B. nach ~/helm kopieren, dann:
#   cd ~/helm && chmod +x setup.sh && ./setup.sh
set -euo pipefail
cd "$(dirname "$0")"
HELM_DIR="$(pwd)"

echo "==> Pakete installieren"
sudo apt update
sudo apt install -y --no-install-recommends \
  python3-picamera2 imx500-all python3-venv python3-numpy python3-scipy python3-serial \
  python3-gpiozero python3-lgpio python3-rpi-lgpio python3-spidev python3-pil \
  libportaudio2 alsa-utils espeak-ng unzip wget

echo "==> Benutzerrechte (Audio, Kamera, GPIO, SPI, Seriell)"
sudo usermod -aG audio,video,gpio,spi,dialout "$USER"

echo "==> config.txt: SPI für das OLED, I2S-Overlay für den Außen-Verstärker"
CFG=/boot/firmware/config.txt
add_line() { grep -qxF "$1" "$CFG" || echo "$1" | sudo tee -a "$CFG" >/dev/null; }
add_line "dtparam=spi=on"
add_line "dtoverlay=max98357a"

echo "==> Python-Umgebung (nutzt picamera2 & Co. aus dem System mit)"
python3 -m venv --system-site-packages venv
venv/bin/pip install --upgrade pip
venv/bin/pip install vosk sounddevice luma.oled

echo "==> Vosk-Sprachmodell Deutsch (klein, ca. 45 MB)"
mkdir -p models
if [ ! -d models/vosk-model-small-de-0.15 ]; then
  wget -q --show-progress -O /tmp/vosk-de.zip https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip
  unzip -q /tmp/vosk-de.zip -d models
  rm /tmp/vosk-de.zip
fi

echo "==> COCO-Labels für die Objekterkennung"
[ -f coco_labels.txt ] || wget -q -O coco_labels.txt \
  https://raw.githubusercontent.com/raspberrypi/picamera2-examples/main/examples/imx500/assets/coco_labels.txt

# Optional: natürlichere Stimme innen (Piper) statt espeak-ng
#   venv/bin/pip install piper-tts
#   venv/bin/python -m piper.download_voices de_DE-kerstin-low --download-dir voices

echo "==> Autostart einrichten (systemd)"
sed -e "s#__USER__#$USER#g" -e "s#__DIR__#$HELM_DIR#g" helm.service \
  | sudo tee /etc/systemd/system/helm.service >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable helm.service

echo
echo "Fertig. Jetzt neu starten:  sudo reboot"
echo "Danach Audiogeräte prüfen:  $HELM_DIR/venv/bin/python -m sounddevice   und   aplay -L"
echo "Log ansehen:                journalctl -u helm -f"
