#!/usr/bin/env python3
"""
helm.py – Steuerprogramm für den Spartan-Helm (Raspberry Pi 5)

  Stimme nach außen   Mikrofon -> Funk-Effekt -> I2S-Verstärker -> Außenlautsprecher
  Sprachbefehle       Push-to-Talk-Taster halten, Befehl sprechen (Vosk, offline)
  Rückmeldungen       Sprachausgabe + Pieptöne auf den 2 inneren Lautsprechern
  HUD                 transparentes OLED 128x64 (SSD1309, SPI) mit Bewegungsmelder
  Objekterkennung     Raspberry Pi AI Camera (IMX500) – das Netz rechnet auf dem Kamerachip
  Effekte             Visier-LEDs, Rücken-LEDs, Lüfter, Nebler über den Arduino (USB)

Jedes Modul startet unabhängig: Fällt eines aus (z. B. Kamera fehlt), läuft der Rest weiter.
Testen ohne Mikrofon: Programm im Terminal starten und Befehle eintippen, z. B. "visier rot".
"""
import glob
import json
import math
import os
import queue
import signal
import subprocess
import sys
import tempfile
import threading
import time
import wave
from collections import namedtuple

import numpy as np

# ═══════════════════════════════ KONFIGURATION ═══════════════════════════════
BASE = os.path.dirname(os.path.abspath(__file__))

# Audio – Gerätenamen prüfen mit:  python3 -m sounddevice   und   aplay -L
MIC_DEVICE   = "USB"                        # Teil des Namens der USB-Soundkarte (Eingang)
OUTER_DEVICE = "MAX98357"                   # Teil des Namens des I2S-Verstärkers (außen)
INNER_ALSA   = "plughw:CARD=Device,DEV=0"   # ALSA-Name der USB-Soundkarte (Ausgang innen)

# Stimme nach außen (Funk-Effekt)
VOICE_GATE   = 0.010        # Rauschsperre: darunter bleibt der Außenlautsprecher stumm
VOICE_BAND   = (300, 3400)  # Funk-Bandbreite in Hz
VOICE_DRIVE  = 6.0          # Vorverstärkung in die Sättigung ("Helmfunk"-Charakter)
VOICE_HISS   = 0.004        # leises Funkrauschen, solange gesprochen wird
VOICE_VOLUME = 0.8

# Sprachbefehle
VOSK_MODEL   = os.path.join(BASE, "models", "vosk-model-small-de-0.15")
PTT_GPIO     = 17           # Taster zwischen GPIO17 (Pin 11) und GND (Pin 9)

# Sprachausgabe innen
PIPER_VOICE  = os.path.join(BASE, "voices", "de_DE-kerstin-low.onnx")   # optional
ESPEAK_CMD   = ["espeak-ng", "-v", "de+f3", "-s", "165"]                # Fallback

# HUD
OLED_DC, OLED_RST = 25, 24
HUD_FPS      = 8
HUD_MIRROR   = False        # True, wenn das Bild über eine Glasscheibe gespiegelt wird

# Kamera / KI
AI_MODEL     = "/usr/share/imx500-models/imx500_network_ssd_mobilenetv2_fpnlite_320x320_pp.rpk"
AI_LABELS    = os.path.join(BASE, "coco_labels.txt")
AI_THRESHOLD = 0.55
CAM_FLIP_X   = False        # True, wenn die Kamera kopfüber eingebaut ist
CAM_HFOV_DEG = 66           # horizontaler Bildwinkel (für den Bewegungsmelder)
ANNOUNCE     = {"person": "Person", "dog": "Hund", "cat": "Katze"}   # Ansage im Scanner-Modus
ANNOUNCE_PAUSE = 12.0

# Arduino
SERIAL_PORTS = ["/dev/ttyUSB*", "/dev/ttyACM*"]
SERIAL_BAUD  = 115200

# Startzustand
VISOR_COLOR  = (255, 140, 0)    # Gold
BACK_COLOR   = (0, 90, 255)
FAN_DEFAULT  = 60

COLORS = {
    "rot": (255, 0, 0), "grün": (0, 255, 0), "blau": (0, 60, 255), "gelb": (255, 200, 0),
    "orange": (255, 80, 0), "gold": (255, 140, 0), "weiß": (255, 255, 255),
    "lila": (150, 0, 255), "türkis": (0, 255, 170), "pink": (255, 0, 110),
}
EFFECTS = {"puls": "PULSE", "regenbogen": "RAINBOW", "lauflicht": "CHASE",
           "feuer": "FIRE", "blinken": "ALERT"}
KEYWORDS = ["visier", "rücken", "licht", "nebel", "links", "rechts", "kurz", "lang", "show",
            "alarm", "stopp", "ruhe", "lüfter", "voll", "leise", "normal", "stärker",
            "schwächer", "aus", "an", "scanner", "stimme", "status", "heller", "dunkler"]
VOCAB = sorted(set(KEYWORDS) | set(COLORS) | set(EFFECTS))

LABELS_DE = {
    "person": "Person", "dog": "Hund", "cat": "Katze", "car": "Auto", "bicycle": "Fahrrad",
    "chair": "Stuhl", "bottle": "Flasche", "cup": "Tasse", "cell phone": "Handy",
    "backpack": "Rucksack", "handbag": "Tasche", "bird": "Vogel", "book": "Buch",
    "laptop": "Laptop", "tv": "TV", "umbrella": "Schirm", "dining table": "Tisch",
    "motorcycle": "Motorrad", "bus": "Bus", "truck": "LKW",
}

Det = namedtuple("Det", "name score x area")   # x: 0 = links … 1 = rechts, area: Anteil am Bild


def log(*args):
    print(time.strftime("%H:%M:%S"), *args, flush=True)


def cpu_temp():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            return int(f.read()) / 1000.0
    except OSError:
        return 0.0


# ═══════════════════════════════ ARDUINO-LINK ═══════════════════════════════
try:
    import serial
except ImportError:
    serial = None


class FxLink:
    """Schickt Befehle an den Nano, prüft die Antwort und stellt nach einem Neustart den Zustand wieder her."""

    def __init__(self, on_event):
        self.q = queue.Queue()
        self.on_event = on_event
        self.online = False
        self.state = {}          # Schlüssel -> letzter Befehl (wird nach Reconnect erneut gesendet)
        if serial is None:
            log("pyserial fehlt – Effekte deaktiviert")
            return
        threading.Thread(target=self._loop, daemon=True).start()

    def send(self, line, key=None):
        if key:
            self.state[key] = line
        self.q.put(line)

    def _resync(self):
        for line in list(self.state.values()):
            self.q.put(line)

    def _open(self):
        for pattern in SERIAL_PORTS:
            for port in sorted(glob.glob(pattern)):
                try:
                    s = serial.Serial(port, SERIAL_BAUD, timeout=0.05)
                    time.sleep(2.0)                  # Nano startet beim Öffnen neu
                    s.reset_input_buffer()
                    log("Arduino verbunden:", port)
                    return s
                except (OSError, serial.SerialException):
                    continue
        return None

    def _event(self, text):
        if text == "READY":
            self._resync()
        elif text.startswith("EVT "):
            self.on_event(text[4:])

    def _transact(self, ser, line):
        for _ in range(3):
            ser.write(b"\n")                         # weckt den Nano, pausiert dort kurz die LED-Ausgabe
            time.sleep(0.01)
            ser.write((line + "\n").encode())
            deadline = time.time() + 0.3
            while time.time() < deadline:
                resp = ser.readline().decode(errors="ignore").strip()
                if not resp:
                    continue
                if resp in ("OK", "PONG"):
                    return True
                if resp.startswith("ERR"):
                    log(f"Arduino lehnt ab: {line} -> {resp}")
                    return True
                self._event(resp)
        return False

    def _loop(self):
        ser, last_ping = None, 0.0
        while True:
            if ser is None:
                self.online = False
                ser = self._open()
                if ser is None:
                    time.sleep(2)
                    continue
                self._resync()
            try:
                while ser.in_waiting:
                    self._event(ser.readline().decode(errors="ignore").strip())
                try:
                    line = self.q.get(timeout=0.1)
                except queue.Empty:
                    if time.time() - last_ping < 5:
                        continue
                    line = "PING"
                self.online = self._transact(ser, line)
                if line == "PING":
                    last_ping = time.time()
            except (OSError, serial.SerialException) as e:
                log("Arduino getrennt:", e)
                try:
                    ser.close()
                except Exception:
                    pass
                ser = None


# ═══════════════════════════════ AUDIO INNEN ═══════════════════════════════
class InnerAudio:
    """Pieptöne und Sprachausgabe auf den inneren Lautsprechern (eine Warteschlange, nichts überlappt)."""

    def __init__(self):
        self.q = queue.Queue()
        self.voice = None
        if os.path.exists(PIPER_VOICE):
            try:
                from piper import PiperVoice
                self.voice = PiperVoice.load(PIPER_VOICE)
                log("Piper-Stimme geladen")
            except Exception as e:
                log("Piper nicht nutzbar, nehme espeak-ng:", e)
        self.beeps = {"on": self._tone(1400, 0.07), "off": self._tone(900, 0.07),
                      "ok": self._tone(1800, 0.05), "err": self._tone(400, 0.2)}
        threading.Thread(target=self._loop, daemon=True).start()

    @staticmethod
    def _tone(freq, dur, sr=48000):
        t = np.arange(int(sr * dur)) / sr
        env = np.clip(np.minimum(t, dur - t) / 0.008, 0, 1)
        data = (0.35 * np.sin(2 * np.pi * freq * t) * env * 32767).astype(np.int16)
        path = os.path.join(tempfile.gettempdir(), f"helm_tone_{freq}.wav")
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(data.tobytes())
        return path

    def beep(self, kind="ok"):
        self.q.put(("wav", self.beeps[kind]))

    def say(self, text):
        self.q.put(("say", text))

    def _play(self, path):
        subprocess.run(["aplay", "-q", "-D", INNER_ALSA, path], check=False)

    def _loop(self):
        tts_path = os.path.join(tempfile.gettempdir(), "helm_tts.wav")
        while True:
            kind, val = self.q.get()
            try:
                if kind == "wav":
                    self._play(val)
                elif self.voice:
                    with wave.open(tts_path, "wb") as wf:
                        if hasattr(self.voice, "synthesize_wav"):
                            self.voice.synthesize_wav(val, wf)
                        else:                              # ältere Piper-Versionen
                            self.voice.synthesize(val, wf)
                    self._play(tts_path)
                else:
                    tts = subprocess.Popen(ESPEAK_CMD + ["--stdout", val], stdout=subprocess.PIPE)
                    subprocess.run(["aplay", "-q", "-D", INNER_ALSA], stdin=tts.stdout, check=False)
                    tts.wait()
            except Exception as e:
                log("Audio innen:", e)


# ═══════════════════════════════ STIMME & BEFEHLE ═══════════════════════════════
class RadioVoice:
    """Helmfunk: Bandpass + Sättigung + Rauschsperre mit weichen Übergängen."""

    def __init__(self, sr, block):
        from scipy.signal import butter, sosfilt
        self._sosfilt = sosfilt
        self.sos = butter(4, VOICE_BAND, btype="bandpass", fs=sr, output="sos")
        self.zi = np.zeros((self.sos.shape[0], 2))
        self.gain = 0.0
        self.hold = 0
        self.hold_blocks = max(1, int(0.25 * sr / block))    # 250 ms Nachlauf
        self.rng = np.random.default_rng()

    def process(self, x):
        rms = float(np.sqrt(np.mean(x * x)))
        if rms > VOICE_GATE:
            self.hold = self.hold_blocks
        elif self.hold > 0:
            self.hold -= 1
        target = 1.0 if self.hold > 0 else 0.0
        new = self.gain + (target - self.gain) * (0.6 if target > self.gain else 0.15)
        ramp = np.linspace(self.gain, new, len(x))
        self.gain = new
        y, self.zi = self._sosfilt(self.sos, x, zi=self.zi)
        y = np.tanh(y * VOICE_DRIVE) + self.rng.uniform(-VOICE_HISS, VOICE_HISS, len(x))
        return (y * ramp * VOICE_VOLUME).astype(np.float32)


class AudioEngine:
    """Mikrofon -> (PTT gedrückt) Spracherkennung  |  (sonst) Funkstimme nach außen."""

    def __init__(self, helm):
        import sounddevice as sd
        self.sd = sd
        self.helm = helm
        self.ptt = False
        self.voice_on = True
        self.level = 0.0
        self.cmd_q = queue.Queue()
        self.out_q = queue.Queue(maxsize=6)
        self.recognizer_ok = False

        mic = self._find(MIC_DEVICE, "input")
        try:
            outer = self._find(OUTER_DEVICE, "output")
            self.out_ch = min(2, sd.query_devices(outer)["max_output_channels"])
        except RuntimeError as e:
            log(e, "– Stimme nach außen deaktiviert")
            outer, self.out_ch = None, 0

        self.sr = None
        for sr in (48000, 44100):
            try:
                sd.check_input_settings(device=mic, samplerate=sr, channels=1, dtype="float32")
                if outer is not None:
                    sd.check_output_settings(device=outer, samplerate=sr, channels=self.out_ch, dtype="float32")
                self.sr = sr
                break
            except Exception:
                continue
        if self.sr is None:
            raise RuntimeError("Keine gemeinsame Abtastrate für Mikrofon und Außenlautsprecher")
        self.block = self.sr // 100
        self.fx = RadioVoice(self.sr, self.block)

        self.streams = [sd.InputStream(device=mic, samplerate=self.sr, blocksize=self.block,
                                       channels=1, dtype="float32", callback=self._in_cb)]
        if outer is not None:
            self.streams.append(sd.OutputStream(device=outer, samplerate=self.sr, blocksize=self.block,
                                                channels=self.out_ch, dtype="float32", callback=self._out_cb))
        for s in self.streams:
            s.start()
        log(f"Audio läuft ({self.sr} Hz)")
        threading.Thread(target=self._vosk_loop, daemon=True).start()

    def _find(self, name, kind):
        key = "max_input_channels" if kind == "input" else "max_output_channels"
        for i, dev in enumerate(self.sd.query_devices()):
            if name.lower() in dev["name"].lower() and dev[key] > 0:
                return i
        raise RuntimeError(f"Audiogerät '{name}' ({kind}) nicht gefunden – siehe 'python3 -m sounddevice'")

    # --- Echtzeit-Callbacks: hier nur rechnen, nie blockieren ---
    def _in_cb(self, indata, frames, t, status):
        x = indata[:, 0].copy()
        self.level = float(np.sqrt(np.mean(x * x)))
        if self.ptt:
            self.cmd_q.put((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())
            y = np.zeros_like(x)
        elif self.voice_on:
            y = self.fx.process(x)
        else:
            y = np.zeros_like(x)
        if self.out_ch:
            try:
                self.out_q.put_nowait(y)
            except queue.Full:                      # Latenz begrenzen: ältesten Block verwerfen
                try:
                    self.out_q.get_nowait()
                except queue.Empty:
                    pass
                self.out_q.put_nowait(y)

    def _out_cb(self, outdata, frames, t, status):
        try:
            y = self.out_q.get_nowait()
        except queue.Empty:
            y = None
        if y is None or len(y) != frames:
            outdata.fill(0)
        else:
            outdata[:] = y[:, None]

    # --- Push-to-Talk ---
    def start_command(self):
        self.ptt = True

    def end_command(self):
        self.ptt = False
        self.cmd_q.put(None)

    def _vosk_loop(self):
        if not os.path.isdir(VOSK_MODEL):
            log("Vosk-Modell fehlt:", VOSK_MODEL)
            return
        try:
            from vosk import KaldiRecognizer, Model, SetLogLevel
            SetLogLevel(-1)
            rec = KaldiRecognizer(Model(VOSK_MODEL), self.sr,
                                  json.dumps([" ".join(VOCAB), "[unk]"], ensure_ascii=False))
            self.recognizer_ok = True
            log("Spracherkennung bereit")
        except Exception as e:
            log("Vosk-Fehler:", e)
            return
        parts = []
        while True:
            item = self.cmd_q.get()
            if item is None:                         # Taster losgelassen -> auswerten
                parts.append(json.loads(rec.FinalResult()).get("text", ""))
                text = " ".join(parts).replace("[unk]", " ")
                parts = []
                rec.Reset()
                self.helm.on_command_text(" ".join(text.split()))
            elif rec.AcceptWaveform(item):
                parts.append(json.loads(rec.Result()).get("text", ""))


# ═══════════════════════════════ OBJEKTERKENNUNG ═══════════════════════════════
class Detector:
    def __init__(self, helm):
        self.helm = helm
        self.dets = []
        self.ok = False
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        try:
            from picamera2 import Picamera2
            from picamera2.devices import IMX500
            from picamera2.devices.imx500 import NetworkIntrinsics

            imx = IMX500(AI_MODEL)                   # muss vor Picamera2() passieren
            intr = imx.network_intrinsics or NetworkIntrinsics()
            if not intr.task:
                intr.task = "object detection"
            if intr.labels is None:
                with open(AI_LABELS) as f:
                    intr.labels = f.read().splitlines()
            intr.update_with_defaults()
            labels = intr.labels
            cam = Picamera2(imx.camera_num)
            cfg = cam.create_preview_configuration(controls={"FrameRate": intr.inference_rate}, buffer_count=12)
            cam.start(cfg, show_preview=False)
            self.ok = True
            log("AI-Kamera läuft")
        except Exception as e:
            log("AI-Kamera nicht verfügbar:", e)
            return

        while self.helm.running:
            try:
                out = imx.get_outputs(cam.capture_metadata(), add_batch=True)
                if out is None:
                    continue
                boxes, scores, classes = out[0][0], out[1][0], out[2][0]
                if intr.bbox_normalization:
                    boxes = boxes / imx.get_input_size()[1]
                if intr.bbox_order == "xy":
                    boxes = boxes[:, [1, 0, 3, 2]]
                dets = []
                for box, score, cls in zip(boxes, scores, classes):
                    if score < AI_THRESHOLD:
                        continue
                    idx = int(cls)
                    name = labels[idx] if 0 <= idx < len(labels) else f"#{idx}"
                    if name in ("-", ""):
                        continue
                    y0, x0, y1, x1 = (float(v) for v in box)
                    xc = (x0 + x1) / 2
                    if CAM_FLIP_X:
                        xc = 1 - xc
                    dets.append(Det(name, float(score), min(max(xc, 0), 1), max(0.0, (x1 - x0) * (y1 - y0))))
                dets.sort(key=lambda d: -d.score)
                self.dets = dets[:6]
                self.helm.on_detections(self.dets)
            except Exception as e:
                log("Erkennung:", e)
                time.sleep(0.5)


# ═══════════════════════════════ HUD ═══════════════════════════════
class Hud:
    def __init__(self, helm):
        from luma.core.interface.serial import spi
        from luma.oled.device import ssd1309
        from PIL import ImageFont
        self.helm = helm
        self.dev = ssd1309(spi(port=0, device=0, gpio_DC=OLED_DC, gpio_RST=OLED_RST, bus_speed_hz=8_000_000))
        self.font = ImageFont.load_default()
        threading.Thread(target=self._loop, daemon=True).start()
        log("HUD läuft")

    def _loop(self):
        from PIL import Image, ImageDraw, ImageOps
        while self.helm.running:
            try:
                img = Image.new(self.dev.mode, self.dev.size)
                self._draw(ImageDraw.Draw(img), time.time())
                self.dev.display(ImageOps.mirror(img) if HUD_MIRROR else img)
            except Exception as e:
                log("HUD:", e)
                time.sleep(1)
            time.sleep(1 / HUD_FPS)
        self.dev.clear()

    def _draw(self, d, now):
        h, f, W = self.helm, self.font, "white"
        a = h.audio
        # Kopfzeile: Modus | Mikrofonpegel | Effekt-Link | Scanner | Temperatur
        d.text((0, 0), "CMD" if a and a.ptt else ("COM" if a and a.voice_on else "---"), font=f, fill=W)
        lvl = min(1.0, (a.level if a else 0.0) * 8)
        d.rectangle((26, 3, 50, 7), outline=W)
        if lvl > 0.03:
            d.rectangle((26, 3, 26 + int(24 * lvl), 7), fill=W)
        d.text((56, 0), "FX" if h.fx.online else "FX!", font=f, fill=W)
        if h.scanner:
            d.text((76, 0), "SCN", font=f, fill=W)
        d.text((104, 0), f"{cpu_temp():.0f}C", font=f, fill=W)
        d.line((0, 11, 127, 11), fill=W)

        # Links: erkannte Objekte, unten Statusmeldung
        det = h.detector
        dets = det.dets if det else []
        if not det or not det.ok:
            d.text((0, 14), "CAM OFFLINE", font=f, fill=W)
        for i, o in enumerate(dets[:3]):
            d.text((0, 14 + i * 11), f"{LABELS_DE.get(o.name, o.name)[:9]} {o.score * 100:.0f}", font=f, fill=W)
        if now < h.msg_until:
            d.text((0, 52), h.msg[:12], font=f, fill=W)

        # Rechts: Bewegungsmelder (vorne = oben, nah = Mitte)
        cx, cy, r = 105, 40, 21
        d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=W)
        d.ellipse((cx - 2, cy - 2, cx + 2, cy + 2), outline=W)
        sweep = (now * 2.0) % (2 * math.pi)
        d.line((cx, cy, cx + r * math.sin(sweep), cy - r * math.cos(sweep)), fill=W)
        half_fov = math.radians(CAM_HFOV_DEG / 2)
        for o in dets:
            ang = (o.x - 0.5) * 2 * half_fov
            dist = min(1.0, max(0.2, 1.1 - math.sqrt(o.area) * 1.4)) * (r - 3)
            px, py = cx + dist * math.sin(ang), cy - dist * math.cos(ang)
            d.ellipse((px - 2, py - 2, px + 2, py + 2), fill=W)


# ═══════════════════════════════ HAUPTPROGRAMM ═══════════════════════════════
class Helm:
    def __init__(self):
        self.running = True
        self.msg, self.msg_until = "", 0.0
        self.scanner = False
        self.colors = {"V": VISOR_COLOR, "B": BACK_COLOR}
        self.bri = {"V": 160, "B": 200}
        self.fan_user = FAN_DEFAULT
        self.last_announce = {}
        self.audio = self.detector = self.hud = None

        self.inner = InnerAudio()
        self.fx = FxLink(self.on_fx_event)
        self.set_group("V", "PULSE")
        self.set_group("B", "OFF")
        for g in ("V", "B"):
            self.fx.send(f"BRI {g} {self.bri[g]}", key=f"BRI {g}")

        self.audio = self._start("Audio", AudioEngine)
        self.detector = self._start("Kamera", Detector)
        self.hud = self._start("HUD", Hud)
        self._setup_ptt()
        threading.Thread(target=self._fan_loop, daemon=True).start()
        if sys.stdin and sys.stdin.isatty():
            threading.Thread(target=self._stdin_loop, daemon=True).start()
        self.say("Systeme online.")

    def _start(self, name, cls):
        try:
            return cls(self)
        except Exception as e:
            log(f"{name} nicht gestartet:", e)
            return None

    def _setup_ptt(self):
        try:
            from gpiozero import Button
            self.ptt_button = Button(PTT_GPIO, pull_up=True, bounce_time=0.03)
            self.ptt_button.when_pressed = self.ptt_down
            self.ptt_button.when_released = self.ptt_up
        except Exception as e:
            log("PTT-Taster nicht verfügbar:", e)

    # --- Hilfsfunktionen ---
    def show_msg(self, text, secs=3.0):
        self.msg, self.msg_until = text, time.time() + secs

    def say(self, text):
        log("»", text)
        self.show_msg(text.upper())
        self.inner.say(text)

    def set_group(self, g, mode, color=None):
        if color:
            self.colors[g] = color
        r, gr, b = self.colors[g]
        self.fx.send(f"{g} {mode} {r} {gr} {b}", key=g)

    def set_scanner(self, on):
        self.scanner = on
        self.set_group("V", "SCAN" if on else "PULSE")
        self.say("Scanner aktiv." if on else "Scanner aus.")

    # --- Ereignisse ---
    def ptt_down(self):
        if self.audio:
            self.audio.start_command()
        self.inner.beep("on")

    def ptt_up(self):
        if self.audio:
            self.audio.end_command()
            if not self.audio.recognizer_ok:
                self.say("Spracherkennung nicht verfügbar.")
        self.inner.beep("off")

    def on_fx_event(self, evt):
        if evt == "BTN":
            self.show_msg("NEBEL!")
        elif evt == "LINKLOST":
            self.show_msg("FX TIMEOUT")

    def on_detections(self, dets):
        if not self.scanner:
            return
        now = time.time()
        for o in dets:
            if o.name in ANNOUNCE and now - self.last_announce.get(o.name, 0) > ANNOUNCE_PAUSE:
                self.last_announce[o.name] = now
                side = "links" if o.x < 0.35 else "rechts" if o.x > 0.65 else "voraus"
                self.say(f"{ANNOUNCE[o.name]} {side}.")

    def show_sequence(self):
        def run():
            self.say("Showtime.")
            self.fx.send("V SCAN 255 140 0")
            self.fx.send("B CHASE 0 120 255")
            time.sleep(1.5)
            self.fx.send("B FIRE 0 0 0")
            self.fx.send("FOG 0 3000")
            time.sleep(3.5)
            self.fx.send("B RAINBOW 0 0 0")
            self.fx.send("V PULSE 255 140 0")
            time.sleep(4.0)
            for key in ("V", "B"):                   # vorherigen Zustand wiederherstellen
                if key in self.fx.state:
                    self.fx.send(self.fx.state[key])
        threading.Thread(target=run, daemon=True).start()

    # --- Sprachbefehle ---
    def on_command_text(self, text):
        log("Befehl erkannt:", repr(text))
        words = text.lower().split()
        w = set(words)
        if not words:
            self.inner.beep("err")
            self.show_msg("??")
            return

        if "nebel" in w:
            side = "1" if "links" in w else "2" if "rechts" in w else "0"
            ms = 4500 if "lang" in w else 1200 if "kurz" in w else 2500
            self.fx.send(f"FOG {side} {ms}")
            self.inner.beep("ok")
            self.show_msg("NEBEL")
        elif "show" in w:
            self.show_sequence()
        elif "alarm" in w:
            self.set_group("V", "ALERT", (255, 0, 0))
            self.set_group("B", "ALERT", (255, 0, 0))
            self.say("Alarm.")
        elif w & {"stopp", "ruhe"}:
            self.fx.send("STOP")
            self.fx.state["B"] = "B OFF"
            self.scanner = False
            self.set_group("V", "PULSE", VISOR_COLOR)
            self.say("Effekte aus.")
        elif "lüfter" in w:
            if w & {"voll"}:
                self.fan_user = 100
            elif "leise" in w:
                self.fan_user = 35
            elif "normal" in w or "an" in w:
                self.fan_user = FAN_DEFAULT
            elif "stärker" in w:
                self.fan_user = min(100, self.fan_user + 20)
            elif "schwächer" in w:
                self.fan_user = max(25, self.fan_user - 20)
            elif "aus" in w:
                self.fan_user = 0
            self.say(f"Lüfter {self.fan_user} Prozent." if self.fan_user else "Lüfter aus.")
        elif "scanner" in w:
            self.set_scanner("aus" not in w)
        elif "stimme" in w:
            if self.audio:
                self.audio.voice_on = "aus" not in w
            self.say("Außenlautsprecher an." if "aus" not in w else "Außenlautsprecher aus.")
        elif "status" in w:
            cam = "aktiv" if self.detector and self.detector.ok else "aus"
            fx = "verbunden" if self.fx.online else "getrennt"
            self.say(f"Temperatur {cpu_temp():.0f} Grad. Effekte {fx}. Kamera {cam}.")
        else:
            self._led_command(words, w)

    def _led_command(self, words, w):
        g = "B" if w & {"rücken", "licht"} else "V"
        color = next((COLORS[x] for x in words if x in COLORS), None)
        effect = next((EFFECTS[x] for x in words if x in EFFECTS), None)
        if w & {"heller", "dunkler"}:
            self.bri[g] = max(20, min(255, self.bri[g] + (60 if "heller" in w else -60)))
            self.fx.send(f"BRI {g} {self.bri[g]}", key=f"BRI {g}")
            self.inner.beep("ok")
        elif "aus" in w and (w & {"visier", "rücken", "licht"}):
            self.set_group(g, "OFF")
            self.inner.beep("ok")
        elif color or effect or "an" in w:
            self.set_group(g, effect or "SOLID", color)
            self.inner.beep("ok")
        else:
            self.inner.beep("err")
            self.show_msg("??")
            return
        self.show_msg(("RUECKEN " if g == "B" else "VISIER ") + (effect or "OK"))

    # --- Hintergrund-Threads ---
    def _fan_loop(self):
        last = None
        while self.running:
            t = cpu_temp()
            boost = 100 if t >= 75 else 80 if t >= 68 else 0
            level = max(self.fan_user, boost)
            if level != last:
                self.fx.send(f"FAN {level}", key="FAN")
                last = level
            time.sleep(5)

    def _stdin_loop(self):
        print("Befehle eintippen (z. B. 'visier rot', 'nebel kurz', 'show'):", flush=True)
        for line in sys.stdin:
            self.on_command_text(line.strip().lower())

    def shutdown(self):
        log("Fahre herunter …")
        self.fx.send("STOP")
        time.sleep(0.8)
        if self.audio:
            for s in self.audio.streams:
                s.stop()
                s.close()


def main():
    helm = Helm()

    def stop(*_):
        helm.running = False

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    while helm.running:
        time.sleep(0.5)
    helm.shutdown()


if __name__ == "__main__":
    main()
